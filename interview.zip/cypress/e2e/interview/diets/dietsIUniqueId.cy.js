describe('Diets tests', () => {
    it('Fetches all diets correctly from the API', () => {
        cy.request('GET','diets')
            .should((response) => {
                expect(response.status).to.eq(200);
                expect(response.body).to.have.length(8);
            });
    });

    it('Checks the integrity of diet data', () => {
        cy.request('GET','diets')
            .should((response) => {
                const ids = response.body.map(diet => diet.id);
                expect(ids).to.have.length(new Set(ids).size); // ensures all IDs are unique
            });
    });
    it('Checks if dietId in offers exist in diets', () => {
        cy.request('http://localhost:3000/offers').then((offersResponse) => {
            const offerDietIds = new Set(offersResponse.body.map(offer => offer.dietId));
            cy.request('http://localhost:3000/diets').then((dietsResponse) => {
                const dietIds = new Set(dietsResponse.body.map(diet => diet.id));
                offerDietIds.forEach(offerDietId => {
                    if (!dietIds.has(offerDietId)) {
                        throw new Error(`Diet with id: ${offerDietId} in offers does not exist in diets`);
                    }
                });
            });
        });
    });
});