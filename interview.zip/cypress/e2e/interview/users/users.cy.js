     it('Checks if all userIds are unique', () => {
        cy.request('GET','/users').then((response) => {
            const userIds = response.body.map(user => user.id);
            const duplicates = userIds.filter((id, index) => userIds.indexOf(id) !== index);
            
            expect(duplicates.length, `Duplicate ids found: ${duplicates}`).to.equal(0);
        });
    });