it('Checks if dietId in offers exist in diets', () => {
    cy.request('GET','offers').then((offersResponse) => {
        const offerDietIds = new Set(offersResponse.body.map(offer => offer.dietId));
        cy.request('GET','/diets').then((dietsResponse) => {
            const dietIds = new Set(dietsResponse.body.map(diet => diet.id));
            offerDietIds.forEach(offerDietId => {
                if (!dietIds.has(offerDietId)) {
                    throw new Error(`Diet with id: ${offerDietId} in offers does not exist in diets`);
                }
            });
        });
    });
});