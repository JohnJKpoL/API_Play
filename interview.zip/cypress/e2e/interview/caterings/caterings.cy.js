    it('Fetches all caterings correctly from the API', () => {
        cy.request('GET','/caterings')
            .should((response) => {
                expect(response.status).to.eq(200);              
            });
    });

    it('Checks the integrity of catering data', () => {
        cy.request('GET','caterings')
            .should((response) => {
                const ids = response.body.map(catering => catering.id);
                expect(ids).to.have.length(new Set(ids).size); 
            });
    });
