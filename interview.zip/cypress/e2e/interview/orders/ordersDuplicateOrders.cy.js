it('Checks for duplicate orders', () => {
    cy.request('GET', 'orders')
        .should((response) => {
            const errors = [];
            const orderMap = new Map();

            response.body.forEach(order => {
                const orderKey = `${order.from_date}-${order.to_date}-${order.dietId}-${order.userId}`;

                if (orderMap.has(orderKey)) {
                    errors.push(`Order with id: ${order.id} is a duplicate of order with id: ${orderMap.get(orderKey)}.`);
                } else {
                    orderMap.set(orderKey, order.id);
                }
            });

            if (errors.length > 0) {
                throw new Error(errors.join('\n'));
            }
        });
});
    