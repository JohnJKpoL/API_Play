describe('Orders tests', () => {
    it('Fetches all orders correctly from the API', () => {
        cy.request('GET','/orders')
            .should((response) => {
                expect(response.status).to.eq(200);
            });
    });
  
});