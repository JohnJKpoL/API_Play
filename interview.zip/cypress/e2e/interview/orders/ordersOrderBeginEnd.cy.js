it('Checks business rules for order data - Orders may begin within 1 to 30 days from the date the order is placed', () => {
    cy.request('GET','orders')
        .then((response) => {
            const invalidOrders = [];

            response.body.forEach(order => {
                const orderDate = new Date(order.datetime.split(" ")[0]); 
                const fromDate = new Date(order.from_date);
                const toDate = new Date(order.to_date);

                
                if (fromDate <= orderDate || fromDate >= new Date(orderDate.getTime() + 31*24*60*60*1000)) {
                    invalidOrders.push(`Order with id: ${order.id} doesn't satisfy the business rule for fromDate.`);
                }

                
                if (toDate <= fromDate || toDate >= new Date(fromDate.getTime() + 31*24*60*60*1000)) {
                    invalidOrders.push(`Order with id: ${order.id} doesn't satisfy the business rule for toDate.`);
                }
            });

            if (invalidOrders.length > 0) {
                throw new Error(invalidOrders.join('\n'));
            }
        });
});