it('Checks business rules for order data - datatime > from_date', () => {
    cy.request('GET', 'orders')
        .should((response) => {
            const errors = [];

            response.body.forEach(order => {
                const orderDate = new Date(order.datetime);
                const fromDate = new Date(order.from_date);

               
                const orderDateWithoutTime = orderDate.setHours(0,0,0,0);
                const fromDateWithoutTime = fromDate.setHours(0,0,0,0);

             
                if (fromDateWithoutTime <= orderDateWithoutTime) {
                    errors.push(`Order with id: ${order.id} doesn't meet the business rule: from_date should be strictly after the date of order.`);
                }
            });

            if (errors.length > 0) {
                throw new Error(errors.join('\n'));
            }
        });
});  