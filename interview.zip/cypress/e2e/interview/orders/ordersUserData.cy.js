it('Checks the integrity of order user data', () => {
    cy.request('GET','/orders')
        .then((response) => {
            const orders = response.body;
            return cy.request('GET','/users')
                .then((usersResponse) => {
                    const userIds = new Set(usersResponse.body.map(user => user.id));
                    orders.forEach(order => {
                        expect(userIds).to.include(order.userId);
                    });
                });
        });
});